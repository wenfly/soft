<?php
$hostname = gethostname();
$workerid = preg_replace("/[^\d]+(\d+)/i", "\\1", $hostname);

ini_set("snowflake.node", $workerid);
var_dump(ini_get("snowflake.node"));

//while(true) {
	
        $id = snowflake_nextid();
        //file_put_contents("./result2", $id."\n", FILE_APPEND);
        var_dump($id);
	//$rt = snowflake_desc($id);
	//var_dump($rt);
        //exit;
//}
